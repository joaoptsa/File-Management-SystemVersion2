package com.version2.apifile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApifileApplicationTests {

	@Test
	void contextLoads() {
	}

}
