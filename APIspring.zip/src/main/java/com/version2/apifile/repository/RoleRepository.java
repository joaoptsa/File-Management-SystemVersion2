package com.version2.apifile.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.version2.apifile.model.RoleModel;



@Repository
public interface RoleRepository extends JpaRepository<RoleModel, Long> {
   
}