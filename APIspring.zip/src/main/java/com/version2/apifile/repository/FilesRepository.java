package com.version2.apifile.repository;


import java.util.Optional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.version2.apifile.model.File;



@Repository
public interface FilesRepository extends JpaRepository<File, Long> {
   
    Optional<File> findByName(String name);

    boolean existsByName(String name);

    Page<File> findAll(Pageable pageable);

    boolean existsByHash(String hash);

    
}