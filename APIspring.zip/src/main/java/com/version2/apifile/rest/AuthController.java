package com.version2.apifile.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.version2.apifile.enums.OAuth2Provider;
import com.version2.apifile.enums.RoleName;
import com.version2.apifile.exception.DuplicatedUserException;
import com.version2.apifile.model.RoleModel;
import com.version2.apifile.model.UserModel;
import com.version2.apifile.security.TokenProvider;


import jakarta.validation.Valid;


@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private com.version2.apifile.Service.userService userService;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private TokenProvider tokenProvider;

 
    
    @PostMapping("/authenticate")
    public AuthResponse login(@Valid @RequestBody LoginRequest loginRequest) {
        String token = authenticateToken(loginRequest.getUsername(), loginRequest.getPassword());
        return new AuthResponse(token);

    }

    private String authenticateToken(String username, String password) {
        Authentication authentication = authenticationManager
                .authenticate(new UsernamePasswordAuthenticationToken(username, password));
        return tokenProvider.generate(authentication);
    }

    @ResponseStatus(HttpStatus.CREATED)
    @PostMapping("/signup")
    public AuthResponse signUp(@Valid @RequestBody SignUpRequest signUpRequest) {
        
        if (userService.hasUserWithUsername(signUpRequest.getUsername())) {
            throw new DuplicatedUserException(
                    String.format("Username %s already been used", signUpRequest.getUsername()));
        }
        if (userService.hasUserWithEmail(signUpRequest.getEmail())) {
            throw new DuplicatedUserException(String.format("Email %s already been used", signUpRequest.getEmail()));
        }

        UserModel user = new UserModel();
        
        
        
        //->>>>>>>>>>>>>>>>>>>>>>><>>Choose admin or user
        
        //User
        //RoleName USER = RoleName.USER;
        //RoleModel rolemodel = new RoleModel(USER);
        
        //Admin
        RoleName USER = RoleName.ADMIN;
        RoleModel rolemodel = new RoleModel(USER);
        
        
        user.setUsername(signUpRequest.getUsername());
        user.setPassword(passwordEncoder.encode(signUpRequest.getPassword()));
        user.setName(signUpRequest.getName());
        user.setEmail(signUpRequest.getEmail());
        user.setRole(rolemodel);
        user.setProvider(OAuth2Provider.LOCAL);
        userService.saveUser(user);
    
       

        String token = authenticateToken(signUpRequest.getUsername(), signUpRequest.getPassword());
        return new AuthResponse(token);
    }

}