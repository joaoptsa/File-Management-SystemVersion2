package com.version2.apifile.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/public")
public class PublicController {

    @Autowired
    private com.version2.apifile.Service.fileService fileService;

   
    @SuppressWarnings("rawtypes")
    @GetMapping("/pageFiles/{number}")
    public Page getNumberOfFiles(@PathVariable Integer number) {
        return fileService.getFiles(number, 10);
    }

    @GetMapping("/numberFiles")
    public Long gettNumberFiles() {
        Long numberOfFiles = fileService.files_number();
        System.out.println(numberOfFiles); 
        return numberOfFiles;
    }
    



}