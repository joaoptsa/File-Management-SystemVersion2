package com.version2.apifile.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import com.version2.apifile.model.File;
import com.version2.apifile.model.UserModel;
import com.version2.apifile.security.CustomUserDetails;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import static com.version2.apifile.config.SwaggerConfig.BEARER_KEY_SECURITY_SCHEME;
import java.security.MessageDigest;
import java.util.Optional;

import org.springframework.security.core.annotation.AuthenticationPrincipal;



@RestController
@RequestMapping("/api/files")
public class FileController {

    @Autowired
    private com.version2.apifile.Service.fileService fileService;

    @Autowired
    private com.version2.apifile.Service.userService userService;

  
   

    @Operation(security = { @SecurityRequirement(name = BEARER_KEY_SECURITY_SCHEME) })
    @DeleteMapping("/delete/{id}")
    public boolean deleteFile(@PathVariable Long id) {
        try {
            File file = fileService.find_id(id);
            fileService.deleteFile(file);
            
            return true;
        } catch (DataAccessException e) {
            return false;
        }
    }

    @Operation(security = { @SecurityRequirement(name = BEARER_KEY_SECURITY_SCHEME) })
    @PostMapping("/create")
    @ResponseStatus(HttpStatus.CREATED)
    public Boolean uploadFiles(@AuthenticationPrincipal CustomUserDetails currentUser,
            @RequestParam("file") MultipartFile file) {

        if (file.getContentType() == null || !file.getContentType().equals("application/zip")) {
            return false;
        }

        if (file.getSize() > 16777216) {
            return false;
        }

        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(file.getBytes());
            byte[] digest = md.digest();
            String hash = bytesToHex(digest);

            if (fileService.verifyHash(hash))
                return false;

            String fileName = file.getOriginalFilename();
            if (fileName == null || fileName.trim().isEmpty()) {
                return false;
            }
            fileName = fileName.substring(0, 10) + "...";

            if (fileService.existName(fileName))
                return false;

            String username = currentUser.getUsername();
            Optional<UserModel> user = userService.getUserByUsername(username);

            if (user == null || !user.isPresent())
                return false;
            UserModel use = user.get();

            File Newfile = new File();
            Newfile.setName(fileName);
            Newfile.setCont(file.getBytes());
            Newfile.setHash(hash);
            Newfile.setAuthor(use);
            fileService.saveFile(Newfile);
           
           
            return true;
        } catch (Exception e) {
            return false;
        }

    }

    // aux

    private static String bytesToHex(byte[] hash) {
        StringBuilder hexString = new StringBuilder(2 * hash.length);
        for (byte b : hash) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) {
                hexString.append('0');
            }
            hexString.append(hex);
        }
        return hexString.toString();
    }

    @SuppressWarnings("null")
    @Operation(security = { @SecurityRequirement(name = BEARER_KEY_SECURITY_SCHEME) })
    @GetMapping("/download/{id}")
    public ResponseEntity<?> downloadContent(@PathVariable(value = "id") Long id) {

        try {
            File file = fileService.find_id(id);
            byte[] bytes = file.getCont();
            return ResponseEntity.status(HttpStatus.OK)
                    .contentType(org.springframework.http.MediaType.APPLICATION_OCTET_STREAM)
                    .header(org.springframework.http.HttpHeaders.CONTENT_DISPOSITION,
                            "attachment; filename=\"" + file.getName() + ".zip" + "\"")
                    .body(bytes);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();

        }

    }

 

}
