package com.version2.apifile.rest;

public record AuthResponse(String accessToken) {
}