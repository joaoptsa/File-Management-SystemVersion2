package com.version2.apifile.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.version2.apifile.DTO.UserDto;
import com.version2.apifile.model.UserModel;
import com.version2.apifile.security.CustomUserDetails;
import com.version2.apifile.webSocket.WebSocketService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import static com.version2.apifile.config.SwaggerConfig.BEARER_KEY_SECURITY_SCHEME;

@RestController
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private com.version2.apifile.Service.userService userService;

    @Autowired
    private WebSocketService webSocketService;

   

   
    @Operation(security = { @SecurityRequirement(name = BEARER_KEY_SECURITY_SCHEME) })
    @GetMapping("/me")
    public UserDto getCurrentUser(@AuthenticationPrincipal CustomUserDetails currentUser) {
        UserModel user = userService.validateAndGetUserByUsername(currentUser.getUsername());
        if (user == null)
            return null;
        else
            return new UserDto(user.getId(), user.getUsername(), user.getName(), user.getEmail(), user.getRole().getAuthority());
    }

    @Operation(security = { @SecurityRequirement(name = BEARER_KEY_SECURITY_SCHEME) })
    @DeleteMapping("/delete/{username}")
    public Boolean deleteUser(@PathVariable String username) {
        try {
            UserModel user = userService.validateAndGetUserByUsername(username);
            if (user == null)
                return false;
            userService.deleteUser(user);
            webSocketService.sendUserNotification(); 
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @Operation(security = { @SecurityRequirement(name = BEARER_KEY_SECURITY_SCHEME) })
    @GetMapping("find/{username}")
    public UserDto getUser(@PathVariable String username) {

        UserModel user = userService.validateAndGetUserByUsername(username);
        if (user == null)
            return null;
        else
            return new UserDto(user.getId(), user.getUsername(), user.getName(), user.getEmail(), user.getRole().getAuthority());

    }

    @SuppressWarnings("rawtypes")
    @Operation(security = { @SecurityRequirement(name = BEARER_KEY_SECURITY_SCHEME) })
    @GetMapping("find/users/{number}")
    public Page getAllUsers(@PathVariable Integer number) {
        return userService.getUsers(number, 10);

    }
}
