package com.version2.apifile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApifileApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApifileApplication.class, args);
	}

}
