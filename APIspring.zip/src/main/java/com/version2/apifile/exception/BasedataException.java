package com.version2.apifile.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.CONFLICT)
public class BasedataException extends RuntimeException {
    public BasedataException(String message) {
        super(message);
    }
}
