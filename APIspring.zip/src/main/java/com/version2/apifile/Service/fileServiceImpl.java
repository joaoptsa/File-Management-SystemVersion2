package com.version2.apifile.Service;

import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;
import com.version2.apifile.DTO.FileDto;
import com.version2.apifile.exception.BasedataException;
import com.version2.apifile.exception.FileNotFoundException;
import com.version2.apifile.model.File;
import com.version2.apifile.repository.FilesRepository;
import com.version2.apifile.webSocket.WebSocketService;


@Service
public class fileServiceImpl implements fileService {

    @Autowired
    private FilesRepository filesRepository;

    @Autowired
    private WebSocketService webSocketService;

   

  

    @SuppressWarnings("null")
    @Override
    public File find_id(Long id) {
        try {
            return filesRepository.findById(id)
                    .orElseThrow(() -> new FileNotFoundException(String.format("file not found")));
        } catch (DataAccessException e) {

            throw new BasedataException("Error File DataBase");
        }
    }

    @SuppressWarnings("null")
    @Override
    public void saveFile(File file) {
        try {
            filesRepository.save(file);
            webSocketService.sendUpdateNotification();
        } catch (DataAccessException e) {
            
            throw new BasedataException("Error File DataBase");
        }
    }

    @SuppressWarnings("null")
    @Override
    public Page<FileDto> getFiles(@RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        try {
            Pageable pageable = PageRequest.of(page, size);
            Page<File> filesPage = filesRepository.findAll(pageable);

            // Page<File> for Page<FileDto>
            List<FileDto> fileDtos = filesPage.getContent().stream()
                    .map(file -> new FileDto(file.getId(), file.getName(), file.getCreatedAt(),
                            file.getAuthor().getUsername(), file.getAuthor().getId()))
                    .collect(Collectors.toList());

            return new PageImpl<>(fileDtos, pageable, filesPage.getTotalElements());
        } catch (DataAccessException e) {
            throw new BasedataException("Error File Database");
        }
    }

    @SuppressWarnings("null")
    @Override
    public void deleteFile(File file) {
        try {
            filesRepository.delete(file);
            webSocketService.sendUpdateNotification();
        } catch (DataAccessException e) {

            throw new BasedataException("Error File DataBase");
        }
    }

    public Boolean verifyHash(String hash) {
        try {
            return filesRepository.existsByHash(hash);
        } catch (DataAccessException e) {
            throw new BasedataException("Error File DataBase");
        }

    }

    public Boolean existName(String name) {

        try {
            return filesRepository.existsByName(name);
        } catch (DataAccessException e) {
            throw new BasedataException("Error File DataBase");
        }
    }

  
    public Long files_number() {
        try {
            return filesRepository.count();
        } catch (DataAccessException e) {
            return 0L;
        }
    }

}
