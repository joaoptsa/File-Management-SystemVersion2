package com.version2.apifile.Service;


import java.util.Optional;
import org.springframework.data.domain.Page;

import com.version2.apifile.DTO.UserDto;
import com.version2.apifile.model.UserModel;



public interface userService {

    Page<UserDto>getUsers(int page,int size);

    Optional<UserModel> getUserByUsername(String username);
      
    Optional<UserModel> getUserByEmail(String email);

    boolean hasUserWithUsername(String username);

    boolean hasUserWithEmail(String email);

    UserModel validateAndGetUserByUsername(String username);

    UserModel saveUser(UserModel user);

    void deleteUser(UserModel user);

    Long users_number();
}