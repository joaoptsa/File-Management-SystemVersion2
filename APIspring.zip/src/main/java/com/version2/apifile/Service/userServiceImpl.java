package com.version2.apifile.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import com.version2.apifile.DTO.UserDto;
import com.version2.apifile.exception.BasedataException;
import com.version2.apifile.exception.UserNotFoundException;
import com.version2.apifile.model.UserModel;
import com.version2.apifile.repository.UserRepository;



@Service
public class userServiceImpl implements userService {

    @Autowired
    private UserRepository userRepository;

   

    

    @SuppressWarnings("null")
    @Override
    public Page<UserDto> getUsers(@RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {

        try {
            Pageable pageable = PageRequest.of(page, size);
            Page<UserModel> filesPage = userRepository.findAll(pageable);

            // Converter Page<File> Page<FileDto>
            List<UserDto> uDtos = filesPage.getContent().stream()
                    .map(user -> new UserDto(user.getId(), user.getUsername(), user.getName(), user.getEmail(),
                            user.getRole().getAuthority()))
                    .collect(Collectors.toList());

            return new PageImpl<>(uDtos, pageable, filesPage.getTotalElements());
        } catch (DataAccessException e) {
            throw new RuntimeException("Error User Database");
        }
    }

    @Override
    public Optional<UserModel> getUserByUsername(String username) {
        try {
            return userRepository.findByUsername(username);
        } catch (DataAccessException e) {
            throw new BasedataException("Error User DataBase");
        }
    }

    @Override
    public Optional<UserModel> getUserByEmail(String email) {
        try {
            return userRepository.findByEmail(email);
        } catch (DataAccessException e) {
            throw new BasedataException("Error User DataBase");
        }
    }

    @Override
    public boolean hasUserWithUsername(String username) {
        try {
            return userRepository.existsByUsername(username);
        } catch (DataAccessException e) {
            throw new BasedataException("Error User DataBase");
        }
    }

    @Override
    public boolean hasUserWithEmail(String email) {
        try {
            return userRepository.existsByEmail(email);
        } catch (DataAccessException e) {
            throw new BasedataException("Error User DataBase");
        }
    }

    @Override
    public UserModel validateAndGetUserByUsername(String username) {
        try {
            return getUserByUsername(username)
                    .orElseThrow(() -> new UserNotFoundException(
                            String.format("User with username %s not found", username)));
        } catch (DataAccessException e) {
            throw new BasedataException("Error User DataBase");
        }
    }

    @SuppressWarnings("null")
    @Override
    public UserModel saveUser(UserModel user) {
        try {
           
            return userRepository.save(user);
           
        } catch (DataAccessException e) {
            throw new BasedataException("Error User DataBase");
        }
    }

    @SuppressWarnings("null")
    @Override
    public void deleteUser(UserModel user) {
        try {
            userRepository.delete(user);
           
        } catch (DataAccessException e) {
            throw new BasedataException("Error User DataBase");
        }
    }

    @Override
    public Long users_number() {
        try {
            return userRepository.count();
        } catch (DataAccessException e) {
            return 0L;
        }
    }

}
