package com.version2.apifile.Service;

import org.springframework.data.domain.Page;
import com.version2.apifile.DTO.FileDto;
import com.version2.apifile.model.File;



public interface fileService {

    Page<FileDto> getFiles(int page, int size);

    File find_id(Long id);

    void saveFile(File file);

    void deleteFile(File file);

    Boolean verifyHash(String hash);
 
    Boolean existName(String name);

    Long files_number(); 
       
}
