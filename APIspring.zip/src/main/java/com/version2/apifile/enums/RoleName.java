package com.version2.apifile.enums;

public enum RoleName {
    ADMIN,
    USER;
    
}

