package com.version2.apifile.enums;


public enum OAuth2Provider {

    LOCAL, GOOGLE
}

