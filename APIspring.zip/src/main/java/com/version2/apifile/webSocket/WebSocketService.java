package com.version2.apifile.webSocket;

import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

@Service
public class WebSocketService {

    private final SimpMessagingTemplate messagingTemplate;

   
    public WebSocketService(SimpMessagingTemplate messagingTemplate) {
        this.messagingTemplate = messagingTemplate;
    }

    public void sendUpdateNotification() {
        messagingTemplate.convertAndSend("/topic/update", "Data updated");
    }

    public void sendUserNotification() {
        messagingTemplate.convertAndSend("/topic/update", "Delete User");
    }
}
