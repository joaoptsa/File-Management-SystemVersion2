package com.version2.apifile.webSocket;

import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.simp.stomp.StompCommand;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.messaging.support.ChannelInterceptor;
import org.springframework.messaging.support.MessageHeaderAccessor;
import com.version2.apifile.exception.UserNotFoundException;
import com.version2.apifile.security.TokenProvider;

public class AuthenticationInterceptor implements ChannelInterceptor {

  
    private final TokenProvider jwtTokenProvider;

    public AuthenticationInterceptor(TokenProvider jwtTokenProvider) {
        this.jwtTokenProvider = jwtTokenProvider;
    }

    @Override
    public Message<?> preSend(Message<?> message, MessageChannel channel) {
        StompHeaderAccessor accessor = MessageHeaderAccessor.getAccessor(message, StompHeaderAccessor.class);
        if (StompCommand.CONNECT.equals(accessor.getCommand())) {
            String authorizationHeader = accessor.getFirstNativeHeader("Authorization");
            if (authorizationHeader != null && authorizationHeader.startsWith("Bearer ")) {
                String token = authorizationHeader.substring(7); 
                if (!jwtTokenProvider.validateTokenAndGetJws(token).isPresent()) {
                    throw new UserNotFoundException("Invalid token");
                }
            } else {
                throw new UserNotFoundException("Authorization header missing or invalid");
            }
        }
        return message;
    }
}

