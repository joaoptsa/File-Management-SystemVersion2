package com.version2.apifile.webSocket;

import org.springframework.messaging.handler.annotation.MessageExceptionHandler;
import org.springframework.messaging.simp.annotation.SendToUser;
import org.springframework.stereotype.Controller;

import com.version2.apifile.exception.UserNotFoundException;

@Controller
public class WebSocketExceptionHandler {

    @MessageExceptionHandler(UserNotFoundException.class)
    @SendToUser("/queue/errors")
    public String handleUserNotFoundException(UserNotFoundException exception) {
        return exception.getMessage();
    }
}