package com.version2.apifile.model;

import java.io.Serializable;
import java.time.LocalDate;
import jakarta.persistence.Basic;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "FILE")
public class File implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "NAME", nullable = false, unique = true)
    private String name;
    @Basic(fetch = FetchType.LAZY)
    @Column(name = "data",columnDefinition = "bytea")
    private byte[] cont;
    @Column(name = "date",nullable = false)
    private String createdAt = LocalDate.now().toString();
    @Column(name = "hash", nullable = false, unique = true)
    private String hash;

    @ManyToOne(cascade = { CascadeType.PERSIST, CascadeType.MERGE })
    @JoinTable(name = "TB_FILES_USERS", joinColumns = @JoinColumn(name = "file_id"), inverseJoinColumns = @JoinColumn(name = "user_id"))
    private UserModel author;

    public File() {
    }

    public File(Long id, String name, byte[] cont, String createdAt, String hash, UserModel author) {
        this.id = id;
        this.name = name;
        this.cont = cont;
        this.createdAt = createdAt;
        this.hash = hash;
        this.author = author;
    }

    public static long getSerialversionuid() {
        return serialVersionUID;
    }

    public String getHash() {
        return hash;
    }

    public void setHash(String hash) {
        this.hash = hash;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public byte[] getCont() {
        return cont;
    }

    public void setCont(byte[] cont) {
        this.cont = cont;
    }

    public UserModel getAuthor() {
        return author;
    }

    public void setAuthor(UserModel author) {
        this.author = author;
    }

  

}
