package com.version2.apifile.DTO;



public record UserDto(Long id, String username, String name, String email, String role) {
}