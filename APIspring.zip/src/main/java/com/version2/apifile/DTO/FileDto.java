package com.version2.apifile.DTO;

public class FileDto {

    private Long id;
    private String name;
    private String createdAt;
    private String user;
    private Long id_user;

    public FileDto() {
    }

    public FileDto(Long id, String name, String createdAt, String user,Long id_user) {
        this.id = id;
        this.name = name;
        this.createdAt = createdAt;
        this.user = user;
        this.id_user=id_user;
    }

    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public Long getId_user() {
        return id_user;
    }

    public void setId_user(Long id_user) {
        this.id_user = id_user;
    }

}
