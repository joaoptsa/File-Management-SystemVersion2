package com.version2.apifile.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.IncorrectClaimException;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.MissingClaimException;
import io.jsonwebtoken.UnsupportedJwtException;
import io.jsonwebtoken.security.Keys;
import io.jsonwebtoken.security.SignatureException;
import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.stereotype.Component;
import com.version2.apifile.enums.OAuth2Provider;
import com.version2.apifile.enums.RoleName;
import com.version2.apifile.model.RoleModel;
import com.version2.apifile.model.UserModel;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Slf4j
@Component
public class TokenProvider {

    private String jwtSecret = "l8GZqIS8AxFpsdxVt0rn0HK8zaVtRmkRSA36cBWeJ78EzNgF2KqSjJM+jGm+h+w6hVYlV7tB8DN+";
    private int jwtExpirationMinutes = 10;
    @Autowired
    private com.version2.apifile.Service.userService userService;

   
  

    // generate token
    public String generate(Authentication authentication) {
        String username = "";
        String name = "";
        String email = "";
        List<String> roles=null;
        System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxe");

        if (authentication instanceof UsernamePasswordAuthenticationToken) {

            System.out.println("Authentication: " + authentication);

            CustomUserDetails user = (CustomUserDetails) authentication.getPrincipal();

            roles = user.getAuthorities()
                    .stream()
                    .map(GrantedAuthority::getAuthority)
                    .collect(Collectors.toList());

            name = user.getName();
            username = user.getUsername();
            email = user.getEmail();
            

        } else {
            
            System.out.println("OAuth2User: " + authentication);
            
            OAuth2User oauth2User = (OAuth2User) authentication.getPrincipal();
            username = oauth2User.getAttribute("sub"); // O ID 
            name = oauth2User.getAttribute("name");
            email = oauth2User.getAttribute("email");
            roles = new ArrayList<>();
            roles.add("USER");
            
            Optional<UserModel> userOptional = userService.getUserByUsername(username);
            UserModel user;
            RoleName USER = RoleName.USER;
            RoleModel rolemodel = new RoleModel(USER);
            
            if (userOptional.isEmpty()) {
                user = new UserModel();
                user.setUsername(username);
                user.setName(name);
                user.setEmail(email);
                user.setProvider(OAuth2Provider.GOOGLE);
                user.setRole(rolemodel);
                userService.saveUser(user);
               

              
            } 

        
        }

        byte[] signingKey = jwtSecret.getBytes();

        return Jwts.builder()
                .header().add("typ", TOKEN_TYPE)
                .and()
                .signWith(Keys.hmacShaKeyFor(signingKey), Jwts.SIG.HS512)
                .expiration(Date.from(ZonedDateTime.now().plusMinutes(jwtExpirationMinutes).toInstant()))
                .issuedAt(Date.from(ZonedDateTime.now().toInstant()))
                .id(UUID.randomUUID().toString())
                .issuer(TOKEN_ISSUER)
                .audience().add(TOKEN_AUDIENCE)
                .and()
                .subject(username)
                .claim("role", roles)
                .claim("name", name)
                .claim("username", username)
                .claim("email", email)
                .compact();
    }

    public Optional<Jws<Claims>> validateTokenAndGetJws(String token) {

        try {

            token = token.replaceAll("\\s", "");
            byte[] signingKey = jwtSecret.getBytes();

            Jws<Claims> jws = Jwts.parser()
                    .verifyWith(Keys.hmacShaKeyFor(signingKey))
                    .requireAudience(TOKEN_AUDIENCE)
                    .requireIssuer(TOKEN_ISSUER)
                    .build()
                    .parseSignedClaims(token);

            return Optional.of(jws);
        } catch (ExpiredJwtException exception) {
            log.error("Request to parse expired JWT : {} failed : {}", token, exception.getMessage());
        } catch (UnsupportedJwtException exception) {
            log.error("Request to parse unsupported JWT : {} failed : {}", token, exception.getMessage());
        } catch (MalformedJwtException exception) {
            log.error("Request to parse invalid JWT : {} failed : {}", token, exception.getMessage());
        } catch (SignatureException exception) {
            log.error("Request to parse JWT with invalid signature : {} failed : {}", token, exception.getMessage());
        } catch (IllegalArgumentException exception) {
            log.error("Request to parse empty or null JWT : {} failed : {}", token, exception.getMessage());
        } catch (MissingClaimException exception) {
            log.error("Request to parse JWT missing required claim : {} failed : {}", token, exception.getMessage());
        } catch (IncorrectClaimException exception) {
            log.error("Request to parse JWT with incorrect claim value : {} failed : {}", token,
                    exception.getMessage());
        }
        return Optional.empty();
    }

    public static final String TOKEN_TYPE = "JWT";
    public static final String TOKEN_ISSUER = "order-api";
    public static final String TOKEN_AUDIENCE = "order-app";
}