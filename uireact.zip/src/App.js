import React from 'react'
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import { AuthProvider } from './Component/context/AuthContext'
import PrivateRoute from './Component/misc/PrivateRoute'
import Navbar from './Component/misc/Navbar'
import Home from './Component/Home/Home'
import Login from './Component/Home/Login'
import Signup from './Component/Home/Signup'
import OAuth2Redirect from './Component/Home/OAuth2Redirect'
import AdminPage from './Component/admin/AdminPage'
import UserPage from './Component/user/UserPage'
import UserPageInfo from './Component/user/UserInfo'
import StyleLink from  './Component/misc/StyleLink'



function App() {
  return (
    <AuthProvider>
      <Router>
        <StyleLink/>
        <Navbar />
        <Routes>
          <Route path='/' element={<Home />} />
          <Route path='/login' element={<Login />} />
          <Route path='/signup' element={<Signup />} />
          <Route path='/oauth2/redirect' element={<OAuth2Redirect />} />
          <Route path="/adminpage" element={<PrivateRoute><AdminPage /></PrivateRoute>}/>
          <Route path="/userpage" element={<PrivateRoute><UserPage /></PrivateRoute>}/>
          <Route path="/userinfo" element={<PrivateRoute><UserPageInfo /></PrivateRoute>}/>
          <Route path="*" element={<Navigate to="/" />}/>
        </Routes>
      </Router>
    </AuthProvider>
  )
}

export default App