import React, { useEffect, useState } from 'react';
import { Navigate } from 'react-router-dom';
import { Container, Grid, Segment, Statistic, Table, Button, Icon, Dimmer, Loader } from 'semantic-ui-react';
import { useAuth } from '../context/AuthContext';
import { fileApi } from '../misc/FileApi';
import { handleLogError } from '../misc/Helpers';
import PaginationButtons from '../misc/PaginationButtons';
import  ComponentWithWebSocket  from '../misc/ComponentWithWebSocket';

function AdminPage() {
  const Auth = useAuth();
  const user = Auth.getUser();
  const tokenn=user.accessToken;
  const isUser = user.data.role[0] === 'ADMIN';

  const [listfiles, setlistfiles] = useState([]);
  const [listusers, setlistUsers] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [number1, setNumber1] = useState(0);
  const [number2, setNumber2] = useState(0);
  const [errorMessage, setErrorMessage] = useState('');
  const [isUploaded, setIsUploaded] = useState(false);
  const [isDelete, setIsDelete] = useState(false);

  
  const fetchData = async () => {
    setIsLoading(true);
    try {
      const response = await fileApi.pagefiles(number1);
      const files = response.data;
      setlistfiles(files);

      const response2 = await fileApi.findUsers(user, number2);
      const users = response2.data;
      setlistUsers(users);
    } catch (error) {
      handleLogError(error)
      setErrorMessage('Error loading files.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [number1, number2, isUploaded, isDelete]);
  
  
 const downloadContent = async (user, id) => {
    try {
      setErrorMessage("");
      await fileApi.downloadContent(user, id);
    } catch (error) {
      console.log(error);
      setErrorMessage('Error download file.');
    }
  };

  const upload = async (user, file) => {
    try {
      setIsUploaded(false);
      setIsDelete(false);
      setErrorMessage("");
      const flag = await fileApi.uploadFile(user, file);

      if (flag === false)
        setErrorMessage("Not valid");
      else setIsUploaded(true);
    } catch (error) {
      setErrorMessage('Error upload file.');
    }
  };

  const deletefile = async (user, id) => {
    try {
      setErrorMessage("");
      setIsDelete(false);
      setIsUploaded(false);
      await fileApi.deleteFile(user, id);
      setIsDelete(true);
    } catch (error) {
      setErrorMessage('Error delete file.');
    }
  };

  const deleteuser = async (user, username) => {
    try {
      setErrorMessage("");
      setIsDelete(false);
      setIsUploaded(false);
      await fileApi.deleteUser(user, username);
      setIsDelete(true);
    } catch (error) {
      console.log(error);
      setErrorMessage('Error delete user.');
    }
  };

  

  if (!isUser) {
    return <Navigate to='/' />;
  }

  if (isLoading) {
    return (
      <Segment basic style={{ marginTop: window.innerHeight / 2 }}>
        <Dimmer active inverted>
          <Loader inverted size='huge'>Loading</Loader>
        </Dimmer>
      </Segment>
    );
  }

  return (
    <Container text>
      <ComponentWithWebSocket onMessageReceived={fetchData} token={tokenn} />
     <Grid stackable columns={1}>
        <Grid.Row>
          <Grid.Column textAlign='center'>
            <Segment color='blue'>
              <Statistic>
                <Statistic.Value style={{ fontSize: '2em' }}><Icon name='smile' color='grey' />{listfiles.length}</Statistic.Value>
                <Statistic.Label style={{ fontSize: '4.5em' }}>ADMIN</Statistic.Label>
              </Statistic>
            </Segment>


            {listfiles.totalPages > 0 && (
              <Table celled>
                <Table.Header>
                  <Table.Row>
                    <Table.HeaderCell>Name</Table.HeaderCell>
                    <Table.HeaderCell>Created At</Table.HeaderCell>
                    <Table.HeaderCell>Author</Table.HeaderCell>
                    <Table.HeaderCell>Actions</Table.HeaderCell>
                  </Table.Row>
                </Table.Header>
                <Table.Body>
                  {listfiles.content.map((file) => (
                    <Table.Row key={file.name}>
                      <Table.Cell>{file.name}</Table.Cell>
                      <Table.Cell>{new Date(file.createdAt).toLocaleString()}</Table.Cell>
                      <Table.Cell>{file.user}</Table.Cell>
                      <Table.Cell>
                        <Button onClick={() => deletefile(user, file.id)}>Delete</Button>
                        <Button onClick={() => downloadContent(user, file.id)}>Download</Button>
                      </Table.Cell>
                    </Table.Row>
                  ))}
                </Table.Body>
                {!listfiles.last && <PaginationButtons setNumber={setNumber2} />}
                {listfiles.last && listfiles.totalPages > 1 && <PaginationButtons setNumber={setNumber2} next={0} />}
              </Table>
            )}
            {listfiles.totalPages === 0 && <p>No files available.</p>}
            <input type="file" onChange={(e) => upload(user, e.target.files[0])} />
            <><br></br></>

            <Table celled>
              <Table.Header>
                <Table.Row>
                  <Table.HeaderCell>Username</Table.HeaderCell>
                  <Table.HeaderCell>Name</Table.HeaderCell>
                  <Table.HeaderCell>Email</Table.HeaderCell>
                  <Table.HeaderCell>Role</Table.HeaderCell>
                  <Table.HeaderCell>Actions</Table.HeaderCell>
                </Table.Row>
              </Table.Header>
              <Table.Body>
                {listusers.content.map((us) => (
                  <Table.Row key={us.username}>
                    <Table.Cell>{us.username}</Table.Cell>
                    <Table.Cell>{us.name}</Table.Cell>
                    <Table.Cell>{us.email}</Table.Cell>
                    <Table.Cell>{us.role}</Table.Cell>
                    <Table.Cell>
                      {us.role != user.data.role  && <Button onClick={() => deleteuser(user, us.username)}>Delete</Button>}

                    </Table.Cell>
                  </Table.Row>
                ))}
              </Table.Body>
              {!listusers.last && <PaginationButtons setNumber={setNumber1} />}
              {listusers.last && listusers.totalPages > 1 && <PaginationButtons setNumber={setNumber1} next={0} />}
            </Table>


            {isUploaded && <p style={{ color: 'blue' }}>Upload success!</p>}
            {isDelete && <p style={{ color: 'blue' }}>Delete success!</p>}
            {errorMessage && <p style={{ color: 'red' }}>{errorMessage}</p>}
          </Grid.Column>
        </Grid.Row>
      </Grid>
    </Container>
  );
}




export default AdminPage