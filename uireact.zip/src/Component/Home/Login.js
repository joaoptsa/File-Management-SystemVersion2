import React, { useState } from 'react'
import { NavLink, Navigate } from 'react-router-dom'
import { Button, Form, Grid, Icon, Segment, Menu, Message, Divider,Header } from 'semantic-ui-react'
import { useAuth } from '../context/AuthContext'
import { fileApi } from '../misc/FileApi'
import { parseJwt, getSocialLoginUrl, handleLogError } from '../misc/Helpers'

function Login() {
  
  const Auth = useAuth()
  const isLoggedIn = Auth.userIsAuthenticated()

  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [isError, setIsError] = useState(false)

  const handleInputChange = (e, { name, value }) => {
    if (name === 'username') {
      setUsername(value)
    } else if (name === 'password') {
      setPassword(value)
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()

    if (!(username && password)) {
      setIsError(true)
      return
    }

    try {
      
      const response = await fileApi.authenticate(username, password)
      const { accessToken } = response.data
      const data = parseJwt(accessToken)
      const authenticatedUser = { data, accessToken }

      Auth.userLogin(authenticatedUser)

      setUsername('')
      setPassword('')
      setIsError(false)
    } catch (error) {
      handleLogError(error)
      setIsError(true)
    }
  }

  if (isLoggedIn) {
    return <Navigate to='/' />
  }

  return (
    <div style={{  backgroundSize: 'cover',
    backgroundRepeat: 'no-repeat',
    width: '100%',
    height: '100vh',backgroundImage: 'url(' + require('./back.jpg')+ ')', display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
    <Grid textAlign='center'>
      <Grid.Column style={{ maxWidth: 450 }}>
      <Header as='h1' color='white' textAlign='center'>
              Login
            </Header>
        <Form size='large' onSubmit={handleSubmit}>
          <Segment>
            <Form.Input
              fluid
              autoFocus
              name='username'
              icon='user'
              iconPosition='left'
              placeholder='Username'
              onChange={handleInputChange}
              style={{ marginBottom: '10px' }}
            />
            <Form.Input
              fluid
              name='password'
              icon='lock'
              iconPosition='left'
              placeholder='Password'
              type='password'
              onChange={handleInputChange}
              style={{ marginBottom: '10px' }}
            />
            <Button color='purple' fluid size='large'>Login</Button>
          </Segment>
        </Form>
        {isError && <Message negative>The username or password provided are incorrect!</Message>}
        <Message>{`Don't have already an account? `}
          <NavLink to="/signup" color='purple'>Sign Up</NavLink>
        </Message>
       

        <Divider horizontal>or connect with</Divider>

        <Menu compact icon='labeled'>
         
          <Menu.Item name='google' href={getSocialLoginUrl()} >
            <Icon name='google' />Google
          </Menu.Item>
         
          
        </Menu>
      </Grid.Column>
    </Grid>
    </div>
  )
}

export default Login
