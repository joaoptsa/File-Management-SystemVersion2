import React from 'react';

function PaginationButtons({ setNumber,next }) {
  
   const handleNext = () => {
    setNumber(prevNumber => prevNumber + 1);
  };

  const handlePrevious = () => {
    setNumber(prevNumber => prevNumber > 0 ? prevNumber - 1 : 0);
  };

  return (
    <div>
      <button className="ui button" onClick={handlePrevious} disabled={setNumber === 0}>Previous</button>
      <button className="ui button" onClick={handleNext}disabled={next === 0}>Next</button>
    </div>
  );
}

export default PaginationButtons;
