import axios from 'axios'
import { config } from '../../Constants'
import { parseJwt } from './Helpers'


export const fileApi = {
  authenticate,
  signup,
  pagefiles,
  findUsername,
  getUserMe,
  deleteUser,
  findUsers,
  findAuthorFile,
  deleteFile,
  downloadContent,
  uploadFile,
  getNumberFiles,
}



async function getNumberFiles() {

  return await instance.get('/public/numberFiles');
}



async function authenticate(username, password) {

  return await instance.post('/auth/authenticate', { username, password }, {
    headers: { 'Content-type': 'application/json' }
  });

}

async function signup(user) {
  return await instance.post('/auth/signup', user, {
    headers: { 'Content-type': 'application/json' }
  });

}

async function pagefiles(number) {
  return await instance.get(`/public/pageFiles/${number}`);
}

async function deleteUser(user, username) {

  const response = await instance.delete(`/api/users/delete/${username}`, {
    headers: { 'Authorization': bearerAuth(user), }
  });
  return response.data;
}

async function getUserMe(user) {

  const response = await instance.get(`api/users/me`, {
    headers: { 'Authorization': bearerAuth(user) }
  });
  return response.data;
}

async function findUsername(user, username) {

  const response = await instance.get(`api/users/find/${username}`, {
    headers: { 'Authorization': bearerAuth(user) }
  });
  return response.data;

}

async function findUsers(user, number) {

  const response = await instance.get(`api/users/find/users/${number}`, {
    headers: { 'Authorization': bearerAuth(user) }
  });
  return response;

}

async function findAuthorFile(user, title) {

  const response = await instance.get(`api/files/author/${title}`, {
    headers: { 'Authorization': bearerAuth(user) }
  });
  return response.data;

}

async function deleteFile(user, id) {

  const response = await instance.delete(`/api/files/delete/${id}`, {
    headers: { 'Authorization': bearerAuth(user), }
  });
  return response.data;

}

async function downloadContent(user, id) {

  const response = await instance.get(`api/files/download/${id}`, {
    responseType: 'blob',
    headers: {
      'Authorization': bearerAuth(user)
    }
  });

  const url = window.URL.createObjectURL(response.data);
  const link = document.createElement('a');
  link.href = url;
  const filename = "Managerfile.zip"
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}


async function uploadFile(user, file) {

  let formData = new FormData();
  formData.append('file', file);

  const response = await instance.post(`api/files/create`, formData, {
    headers: {
      'Authorization': bearerAuth(user),
    }
  });
  return response.data;

}


// -- Axios

const instance = axios.create({
  baseURL: config.url.API_BASE_URL
})

instance.interceptors.request.use(function (config) {
  if (config.headers.Authorization) {
    const token = config.headers.Authorization.split(' ')[1]
    const data = parseJwt(token)
    if (Date.now() > data.exp * 1000) {
      window.location.href = "/login"
    }
  }
  return config
}, function (error) {
  return Promise.reject(error)
})



function bearerAuth(user) {
  return `Bearer ${user.accessToken}`
}