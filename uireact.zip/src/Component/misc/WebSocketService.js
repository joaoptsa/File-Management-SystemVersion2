import SockJS from 'sockjs-client';
import { Client } from '@stomp/stompjs';

const WebSocketService = (token) => {
  let stompClient = null;
  let onMessageReceived = null;
 
  const connect = () => {
    const socket = new SockJS('http://localhost:8080/ws');
    stompClient = new Client({
      webSocketFactory: () => socket,
      connectHeaders: {
        Authorization: `Bearer ${token}`
      },
      debug: (str) => {
        console.log(new Date(), str);
      },
      onConnect: () => {
        console.log('Connected');
        stompClient.subscribe('/topic/update', (message) => {
          handleMessageReceived(message.body);
        });
      },
      onStompError: (frame) => {
        console.error('Broker reported error: ' + frame.headers['message']);
        console.error('Additional details: ' + frame.body);
      },
    });
    stompClient.activate();
  };

  const handleMessageReceived = (message) => {
    console.log('Received message: ' + message);
    if (onMessageReceived) {
      onMessageReceived(message);
    }
  };

  const disconnect = () => {
    if (stompClient !== null) {
      stompClient.deactivate();
    }
    console.log('Disconnected');
  };

  const subscribe = (callback) => {
    onMessageReceived = callback;
  };

  

  return {
    connect,
    disconnect,
    subscribe,
  };
};

export default WebSocketService;

