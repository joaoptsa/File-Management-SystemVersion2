import React, { useEffect } from 'react';
import WebSocketService from './WebSocketService';
import { useAuth } from '../context/AuthContext'


const ComponentWithWebSocket = ({ onMessageReceived, token }) => {
  const {userLogout } = useAuth()
  
  useEffect(() => {
    const webSocketService = WebSocketService(token);
    webSocketService.connect();

    webSocketService.subscribe((message) => {
      console.log('Received message:', message);
      if(message === "Delete User"){
      userLogout()}
      
      onMessageReceived(); 
    });

    return () => {
      webSocketService.disconnect();
    };
  }, [onMessageReceived, token,userLogout]);

  return null;
};

export default ComponentWithWebSocket;


