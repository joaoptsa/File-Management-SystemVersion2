import React, { useEffect, useState} from 'react'
import { Navigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { fileApi } from '../misc/FileApi'
import { handleLogError } from '../misc/Helpers'
import { Container, List, Segment, Header, Icon, Dimmer, Loader, } from 'semantic-ui-react';


function UserPageInfo() {


  const Auth = useAuth()
  const user = Auth.getUser()
  const isUser = user.data.role[0] === 'USER' || user.data.role[0] === 'ADMIN';
  const [infoUser, setInfoUser] = useState([])
  const [isLoading, setIsLoading] = useState(true)
  const [errorMessage, setErrorMessage] = useState('');


  useEffect(() => {
    async function fetchData() {
      setIsLoading(true)
      
      try {
        const response = await fileApi.getUserMe(user)
        const info = response
        console.log(info)
        setInfoUser(info)
       
        

      } catch (error) {
        handleLogError(error)
        setErrorMessage("Error Loading")
      } finally {
        setIsLoading(false)
      }
    }
    fetchData();
  }, [])

  if (!isUser) {
    return <Navigate to='/' />;
  }

  if (isLoading) {
    return (
      <Segment basic style={{ marginTop: window.innerHeight / 2 }}>
        <Dimmer active inverted>
          <Loader inverted size='huge'>Loading</Loader>
        </Dimmer>
      </Segment>
    );
  }

  return (
    <div>
      <br /><br />
      <Container text style={{ marginTop: '2em', textAlign: 'center' }}>
        <Segment raised color='blue'>
          <Header as='h1' icon>
            <Icon name='user' circular />
            <Header.Content>User Information</Header.Content>
          </Header>
          <List relaxed>
            <List.Item>
              <List.Icon name='user' />
              <List.Content>
                <List.Header>Username</List.Header>
                {infoUser.username}
              </List.Content>
              <br />
            </List.Item>
            <List.Item>
              <List.Icon name='user' />
              <List.Content>
                <List.Header>Name</List.Header>
                {infoUser.name}
              </List.Content>
            </List.Item>
            <br />
            <List.Item>
              <List.Icon name='mail' />
              <List.Content>
                <List.Header>Email</List.Header>
                {infoUser.email}
              </List.Content>
            </List.Item>
            <br />
            <List.Item>
              <List.Icon name='shield' />
              <List.Content>
                <List.Header>Authority</List.Header>
                {infoUser.role}
              </List.Content>
            </List.Item>
          </List>
        </Segment>
        {errorMessage && <p style={{ color: 'red' }}>{errorMessage}</p>}
      </Container>
    </div>
  );
  
}




export default UserPageInfo

